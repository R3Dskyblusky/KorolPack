This pack includes:
-One Korolian paintings.
-"Crown of Nebsk" texture. Only item retextured for now :(.