This pack includes:
-Purple and cyan glazed terracotta Vjara-inspired textures.
-Chiselled quartz block Vjara-inspired texture.
-Regular and red sandstone Ehwaism-inspired textures.
-Two Korolian paintings.
-"Crown of Nebsk" texture. Only item retextured for now :(.
-KCorp logo instead of Mojang logo (needs to be fixed).
-Java Edition retextured to Korolian Edition (needs to be improved).
-Korolian-themed custom splashes.
